bars = document.querySelector(".bars");
bars.onclick = function () {
    navBar = document.querySelector(".nav-bar");
    navBar.classList.toggle("active");
}




const swiper = new Swiper('.swiper', {
    // Optional parameters
    direction: 'horizontal',
    loop: true,
  
    // If we need pagination
    pagination: {
      el: '.swiper-pagination',
      clickable: true,
      dynamicBullets: false,
    },
  
    // // Navigation arrows
    // navigation: {
    //   nextEl: '.swiper-button-next',
    //   prevEl: '.swiper-button-prev',
    // },
  
    // // And if we need scrollbar
    // scrollbar: {
    //   el: '.swiper-scrollbar',
    // },
  });
  
/*
const  favorite_onclick = function (b) {
    b.classList.toggle("active");
}
*/
//const fav = document.querySelector(".favorite");
const allFavorites = document.getElementsByClassName("favorite");


// let declara la variable faboriteButton para recorrer todos los valores de la función allFavorites
/*
 for (let faboriteButton of allFavorites){
   faboriteButton.addEventListener("click",()=>{
     faboriteButton.classList.toggle("active");
   });
 }
   */
 
for(let c=0; c<allFavorites.length; c++){
  let faboriteButton = allFavorites.item(c);

  faboriteButton.addEventListener("click",()=>{
    faboriteButton.classList.toggle("active");
  });
}

const boton = document.querySelector("button");
boton.addEventListener("click",(e)=>{
    e.preventDefault();

   

    const regex_nombre =  /^[A-Z][a-z]{2,}$/   /*/\w{4,}/*/;
    const nombre = document.querySelector("#nombre").value;
    const nom_error = document.querySelector("#nombre_error");

    const regex_apellidos =  /^[A-Z][a-záéíóúñ]{2,}([\s][A-Z][a-záéíóúñ]{2,})+$/;
    const apellidos = document.querySelector("#apellidos").value;
    const apellidos_error = document.querySelector("#apellidos_error");
    
    const regex_telf =  /^\+?[1-9][0-9]{8}$/;
    const telf = document.querySelector("#telf").value;
    const telf_error = document.querySelector("#telf_error");

    const regex_cumple =  /^[0-9]{1,2}\/[0-9]{1,2}\/[0-9]{4}$/;
    const cumple = document.querySelector("#cumple").value;
    const cumple_error = document.querySelector("#cumple_error");

    const regex_email =  /^\S+@\S+\.\S+$/;
    const email = document.querySelector("#email").value;
    const email_error = document.querySelector("#email_error");

    const terms = document.querySelector("#terms").checked;
    const terms_error = document.querySelector("#terms_error");

    const form_exito = document.querySelector("#form_exito");

    let bien = true;

    if((nombre!="")&&(regex_nombre.test(nombre))){
        // aqui entra cuando todo ha ido bien
        nom_error.classList.remove("visible");
        // bien = true;
    }
    else{
        nom_error.classList.add("visible");
        bien = false;
        form_exito.classList.remove("visible");
    }

    if((apellidos!="")&&(regex_apellidos.test(apellidos))){
        // aqui entra cuando todo ha ido bien
        apellidos_error.classList.remove("visible");
        // bien = true;
    }
    else{
        apellidos_error.classList.add("visible");
        bien = false;
        form_exito.classList.remove("visible");
    }
    
    if((telf!="")&&(regex_telf.test(telf))){
        // aqui entra cuando todo ha ido bien
        telf_error.classList.remove("visible");
        // bien = true;
    }
    else{
        telf_error.classList.add("visible");
        bien = false;
        form_exito.classList.remove("visible");
    }
    
    if((cumple!="")&&(regex_cumple.test(cumple))){
        // aqui entra cuando todo ha ido bien
        cumple_error.classList.remove("visible");
        // bien = true;
    }
    else{
        cumple_error.classList.add("visible");
        bien = false;
        form_exito.classList.remove("visible");
    }
    
    if((email!="")&&(regex_email.test(email))){
        // aqui entra cuando todo ha ido bien
        email_error.classList.remove("visible");
        // bien = true;
    }
    else{
        email_error.classList.add("visible");
        bien = false;
        form_exito.classList.remove("visible");
    }

    if(terms == true ){
        // aqui entra cuando todo ha ido bien
        terms_error.classList.remove("visible");
        // bien = true;
    }
    else{
        terms_error.classList.add("visible");
        bien = false;
        form_exito.classList.remove("visible");
    }


    if(bien==true){
        form_exito.classList.add("visible");
    }

})


